#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
	int numNames=0;
	char* names[10];
	char name[10];
	
	printf("Enter number of names to store: ");
	//Get number of names to store in names array, store in numNames
	
	//Loop numNames times, allocate a 10-character long C string using
	//malloc. Prompt the user to enter a name, store it in the malloc-ed string.
	//Store the pointer to the string in an element in the names array.
	
	//Loop through the names array, retrieving and printing out the names
	//entered by the user.

	//Loop through the names array, free each malloc-ed piece of memory.
	
	return 0;
}