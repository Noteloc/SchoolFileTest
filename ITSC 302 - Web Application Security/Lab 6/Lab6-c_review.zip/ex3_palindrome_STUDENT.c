#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
	char original[20]={};
	char cleaned[20]={};
	char reversed[20]={};

	printf("Enter string: ");
	//Store string entered by the user in original C string
	
	
	//Make cleaned version of "original" string:
	// - Loop through all the characters in "original"
	//		Take one character, if that character is a numeric digit, or
	//		upper- or lower-case letter, concatenate it to the end of the "cleaned" C string.
	//		(If the letter is upper-case, make it lower case before concatenating it to "cleaned").
	
	//Reverse "cleaned" string, store reversed version in "reversed" C string.
	//Loop from end of "cleaned" string to beginning of it, concatenate one character
	//at a time from "cleaned" to "reversed".
	
	
	//Compare "cleaned" and "reversed" string, if they are the same then output that the
	//original string entered by the user is a palindrome. If they are not the same output that
	//it was not.
		

	return 0;
}