function runFromOtherFile()
{
	alert("Running from other file");
}