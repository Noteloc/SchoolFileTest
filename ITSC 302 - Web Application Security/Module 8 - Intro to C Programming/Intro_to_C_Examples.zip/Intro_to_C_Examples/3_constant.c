#include <stdio.h>

#define PI 3.14159

int main(int argc, char* argv[])
{
	printf("The value of the constant pi is %f\n",PI);
	//PI++;
	return 0;
}