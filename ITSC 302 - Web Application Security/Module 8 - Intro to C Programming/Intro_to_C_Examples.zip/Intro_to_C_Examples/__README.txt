ITSC315 C Intro Sample Programs (Under "examples" subdirectory):

Slide 7: 1_helloWorld.c
Slide 11: 2_dataTypes.c
Slide 13: 3_constant.c
Slide 14: 4_ifElse.c, 5_switch.c
Slide 15: 6_loops.c
Slide 19: 7_input.c
Slide 25: 8_pointer.c
Slide 30: 9_malloc.c, 10_memoryLeak.c
Slide 33: 11_array.c
Slide 35: 12_string.c
Slide 39: 13_stringFns.c
Slide 42: 14_fgets.c
Slide 44: 15_functions.c
Slide 47: 16_PassByValue.c, 17_PassByReference.c
Slide 48: 18_ReturnMulti.c















